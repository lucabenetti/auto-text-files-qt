#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include <QClipboard>
#include <QMessageBox>

QSqlDatabase bancoDeDados = QSqlDatabase::addDatabase("QSQLITE");

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->frequenciaLinha->setFocus();

    bancoDeDados.setDatabaseName(QDir::currentPath()+"/last");
    if(!bancoDeDados.open()) {
        qDebug() << "Banco de dados não aberto!";
    } else qDebug() << "Banco de dados aberto com SUCESSO!";
}

MainWindow::~MainWindow()
{
    delete ui;
}

int nLinhas (QString numero) {
    QSqlQuery query;
    if(!bancoDeDados.isOpen()) {
        qDebug() << "Banco de dados não está aberto";
        return 0;
    }

    query.prepare("select * from "+numero);
    query.exec();
    int c = 0;
    if(query.exec())  {
        while(query.next()){
            c++;
            qDebug() << c;
        }
    }
    return c;
}

bool textoExiste(QString numero, QString disciplina) {
    QSqlQuery query;
    if(query.exec("select * from " + disciplina + " where number = "+ numero)) {
        int c = 0;
        while (query.next()) {
            c++;
        }
        if(c > 0) return true;
        else return false;
    }

}

QString pegaTexto(QString numero, QString disciplina){
    QString temp;
    QSqlQuery query;
    if(!bancoDeDados.isOpen()) {
        qDebug() << "Banco de dados não está aberto";
        return 0;
    }
    qDebug() << "select text from " + disciplina + " where number = " + numero;
    query.prepare("select text from " + disciplina + " where number = " + numero);
    query.exec();
    if(query.exec())  {
        while(query.next()){
            temp = query.value(0).toString();
            qDebug() << temp;
        }
    }
    else {
        qDebug() << "Erro ao pesquisar";
    }

    return temp;
}

QString adicionaTexto(QString numero, QString disciplina, QString texto) {

    QString tmp;
    tmp = pegaTexto(numero, disciplina);
    return texto+tmp+"\n";

}

void atualizaTexto(QString disciplina, QString numero, QString text){
    QSqlQuery query;
    if(!bancoDeDados.isOpen()) {
        qDebug() << "Banco de dados não está aberto";
        return ;
    }

    QString temp = "update "+disciplina+" set text = '"+text+"' where number = "+numero;
    query.prepare(temp);
    qDebug() << temp;

    if(!query.exec()) {
        qDebug() << "Erro!";
    }

}

void insereTexto (QString disciplina, QString numero, QString text) {
    QSqlQuery query;
    if(!bancoDeDados.isOpen()) {
        qDebug() << "Banco de dados não está aberto";
        return ;
    }

    QString temp = "insert into "+disciplina+" values ("+numero+",'"+text+"')";
    query.prepare(temp);
    qDebug() << temp;

    if(!query.exec()) {
        qDebug() << "Erro!";
    }
}

void MainWindow::on_gerarfichaBotao_clicked()
{
    QString frequencia = ui->frequenciaLinha->text();
    QString social = ui->socialLinha->text();
    QString atividade = ui->atividadeLinha->text();
    QString oral = ui->oralLinha->text();
    QString portugues = ui->portuguesLinha->text();
    QString arte = ui->arteLinha->text();
    QString edfisica = ui->educacaofisicaLinha->text();
    QString matematica = ui->matematicaLinha->text();
    QString ciencias = ui->cienciasLinha->text();
    QString historia = ui->historiaLinha->text();
    QString geografia = ui->geografiaLinha->text();
    QString ingles = ui->inglesLinha->text();
    QString texto;

    if(!(textoExiste(frequencia, "frequencia") && textoExiste(social, "social") && textoExiste(atividade, "atividade") && textoExiste(oral, "oral") && textoExiste(portugues, "portugues") && textoExiste(arte, "arte") && textoExiste(edfisica, "edfisica") && textoExiste(matematica, "matematica") && textoExiste(ciencias,"ciencias") && textoExiste(historia, "historia") && textoExiste(geografia, "geografia") && textoExiste(ingles, "ingles"))) {
        QMessageBox::about(this, "", "Você digitou um número de avaliação que não existe.\nReescreva corretamente ou atualize os textos!");
        return;
    }

    texto = adicionaTexto(frequencia, "frequencia", texto);
    texto = adicionaTexto(social, "social", texto);
    texto = adicionaTexto(atividade, "atividade", texto);
    texto = adicionaTexto(oral, "oral", texto);
    texto = adicionaTexto(portugues, "portugues", texto);
    texto = adicionaTexto(arte, "arte", texto);
    texto = adicionaTexto(edfisica, "edfisica", texto);
    texto = adicionaTexto(matematica, "matematica", texto);
    texto = adicionaTexto(ciencias, "ciencias", texto);
    texto = adicionaTexto(historia, "historia", texto);
    texto = adicionaTexto(geografia, "geografia", texto);
    texto = adicionaTexto(ingles, "ingles", texto);

    janela3 = new janelatexto(this, texto);
    janela3->show();

}


void MainWindow::on_atualizarBotao_clicked()
{
    janela2 = new JanelaAtualizar(this);
    janela2->show();
}
