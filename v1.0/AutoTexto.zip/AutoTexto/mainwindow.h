#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "janelaatualizar.h"
#include "janelatexto.h"
#include <QtSql>
#include <QFileInfo>

int nLinhas (QString numero);
void atualizaTexto(QString disciplina, QString numero, QString text);
QString pegaTexto(QString numero, QString disciplina);
void insereTexto (QString disciplina, QString numero, QString text);
bool textoExiste(QString numero, QString disciplina);
QString adicionaTexto(QString numero, QString disciplina, QString texto);

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_gerarfichaBotao_clicked();

    void on_atualizarBotao_clicked();

private:
    Ui::MainWindow *ui;
    JanelaAtualizar *janela2;
    janelatexto *janela3;
};

#endif // MAINWINDOW_H
